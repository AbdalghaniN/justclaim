<?php

    /*!
	 * POCKET v3.7
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2020 DroidOXY ( http://www.droidoxy.com )
	 */
	 
	 include_once("../admin/core/init.inc.php");
	 
	 $_SESSION["refererCode"] = isset($_REQUEST['refer']) ? $_REQUEST['refer']: '';
	 
	 
	 header("Location: ../dashboard/register.php");
	 exit;

?>