<?php

    /*!
	 * POCKET v3.4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2019 DroidOXY ( http://www.droidoxy.com )
	 */

?>

                    <div class="col-12 mb-2">
						<div class="alert alert-danger" role="alert" style="text-align: center;">
						Demo Mode Enabled ! Any changes you make will not be Saved.
						</div>
					</div>